#include "test.hpp"

int Solution::numberOfArrays(vector<int>& differences, int lower, int upper)
{
	int output = 0;
	int max = 0, min = 0;
	long long num = 0;
	for (int i : differences) {
		num += i;
		max = max >= num ? max : num;
		min = min <= num ? min : num;
	}
	output = (upper - lower) - (max - min)+1;
	if (output < 0)
		output = 0;

	
	return output;
}
