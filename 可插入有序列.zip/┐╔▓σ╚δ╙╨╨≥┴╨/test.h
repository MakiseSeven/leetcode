#include<iostream>
#include<list>
#include<string.h>
#include<vector>
using namespace std;

class orderdstream {
private:
	vector<string> value;
	int num;
	int ptr;
public:
	orderdstream(int n) {
		num = n;
		value.resize(n);
		ptr = 0;
	}
	vector<string> insert(int idKey, string inValue);
};