#include<iostream>
#include<list>
#include<string.h>
#include<vector>
#include"test.h"
using namespace std;

vector<string> orderdstream::insert(int idKey, string inValue) {
	value[idKey-1] = inValue;
	vector<string> output;
	if (idKey == ptr) {
	while (ptr <= num && !value[ptr - 1].empty()) {
		output.push_back(value[ptr-1]);
		ptr++;
	}
}
	return output;
}

