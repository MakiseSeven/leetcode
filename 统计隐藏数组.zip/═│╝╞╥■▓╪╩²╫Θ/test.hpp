#include<iostream>
#include<vector>
using namespace std;

class Solution {
public:
    static int numberOfArrays(vector<int>& differences, int lower, int upper);
};