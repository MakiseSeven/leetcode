#include "test.hpp"

int Solution::numberOfArrays(vector<int>& differences, int lower, int upper)
{
	int output = 0;
	int flag = lower;
	int mark = flag;
	while(flag <= upper) {
		int j = 0;
		for (int i = 0; flag >= lower && flag <= upper&&i<differences.size();i++) {
			flag = flag + differences[i];
			if (flag <lower || flag > upper)
				break;
			j++;
		}
		if (j == differences.size()) {
			output++;
			mark++;
			flag = mark;
			continue;
		}
		mark++;
		flag = mark;
	}
	return output;
}
