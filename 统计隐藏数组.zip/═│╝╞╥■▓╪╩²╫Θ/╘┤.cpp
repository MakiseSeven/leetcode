#include<iostream>
#include<vector>
#include"test.hpp"
using namespace std;

int main() {
	vector<int> input = { 3,-4,5,1,-2};
	int lower = -4;
	int upper = 5;
	int output = 0;
	output = Solution::numberOfArrays(input, lower, upper);
	cout << output;
}