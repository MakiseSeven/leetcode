#include "makise.hpp"

queue::queue()
{
	while (!stack1.empty()) {
		stack1.pop();
	}
	while (!stack2.empty()) {
		stack2.pop();
	}

}

void queue::appendtail(int value)
{
	stack1.push(value);
}

int queue::deletetail()
{
	int deletenum;
	if (!stack2.empty()) {
		deletenum = stack2.top();
		stack2.pop();
		return deletenum;
	}
	if (stack2.empty()) {
		while (!stack1.empty()) {
			deletenum = stack1.top();
			stack1.pop();
			stack2.push(deletenum);
		}
		if (stack2.empty()) {
			return -1;
		}
		deletenum = stack2.top();
		stack2.pop();
		return deletenum;
	}
	
	
}
