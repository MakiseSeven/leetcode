#include<iostream>
#include<stack>
using namespace std;

class queue {
public:
	queue();

	void appendtail(int value);

	int deletetail();
private:
	stack<int> stack1, stack2;

};