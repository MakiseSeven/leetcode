#include<iostream>
#include<vector>
#include<list>
using namespace std;

struct ListNode {
    int val;
    ListNode* next;
    ListNode(int x) : val(x), next(NULL) {}
    
};

class Solution {
public:
public:
    vector<int> reversePrint(ListNode* head) {
        vector<int> output1, output2;
        if (!head) {
            return output2;
        }
        while (1) {
            output1.push_back(head->val);
            if (!head->next) {
                break;
            }
            head = head->next;
        }
        output2.reserve(output1.size());
        vector<int>::reverse_iterator riter;
        for (riter = output1.rbegin(); riter != output1.rend(); riter++)
        {
            output2.push_back(*riter);
        }

        return output2;
    }

};